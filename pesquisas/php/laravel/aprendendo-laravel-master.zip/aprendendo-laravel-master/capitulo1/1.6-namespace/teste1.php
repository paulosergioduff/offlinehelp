<?php

namespace teste1;

class Usuario {
    public function __construct()
    {
        return self::class;
    }
}
