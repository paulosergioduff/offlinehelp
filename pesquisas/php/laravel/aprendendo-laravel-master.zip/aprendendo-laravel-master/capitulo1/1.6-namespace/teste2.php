<?php

namespace teste2;

class Usuario {
    public function __construct()
    {
        return self::class;
    }
}
