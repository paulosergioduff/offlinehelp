<?php

class Usuario {
    public function __construct()
    {
        return self::class;
    }
}
