<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MeuModelo extends Model
{
    protected $table = 'nome_da_tabela';
    protected $primaryKey = 'nome_da_coluna';
}
