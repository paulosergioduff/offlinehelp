# Capítulo 16

Capítulo 16 é exclusivo para se trabalhar com banco de dados, em como criar, atualizar e remover registros. Além de ententer como o Laravel abstrair a criação de relações entre modelos e tarefas comuns do dia-a-dia.

# Sessões abordadas

* 16.1 Criando o meu primeiro modelo
* 16.1.1 Criando a base de dados
* 16.1.2 Criando a rota
* 16.1.3 Executando operações com o modelo
* 16.1.4 Lendo e criando dados
* 16.1.5 Removendo dados
* 16.2 Relacionamentos com Eloquent
* 16.2.1 Relacionamento um-para-um

