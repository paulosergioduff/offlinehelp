<?php
$array = array(1, 2, 3, 4);

if(in_array(1, $array))
	echo 'Element found.';
?>
