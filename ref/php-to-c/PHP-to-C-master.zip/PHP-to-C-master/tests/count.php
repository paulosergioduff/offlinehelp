<?php
$array = array(1, 2, 3, 4);
echo count($array);
?>
