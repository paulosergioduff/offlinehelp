<?php
$array = array('This', 'is', 'a', 'test.');
echo implode(', ' $array);
?>
