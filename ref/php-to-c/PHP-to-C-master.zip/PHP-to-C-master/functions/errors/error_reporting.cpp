void error_reporting(php_var error_level)
{
	return;
}
