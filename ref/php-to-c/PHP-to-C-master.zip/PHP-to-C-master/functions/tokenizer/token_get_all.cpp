php_var token_get_all(php_var source)
{
	php_var ret = array();
	int i = 0;
	return ret;
}