#define is_resource(var) ((var).type == PHP_RESOURCE ? (php_var)true : (php_var)false)
