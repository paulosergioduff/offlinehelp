#define is_string(var) ((var).type == PHP_STRING ? (php_var)true : (php_var)false)
