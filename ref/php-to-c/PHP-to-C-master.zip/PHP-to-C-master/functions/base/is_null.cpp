#define is_null(var) ((var).type == PHP_NULL ? (php_var)true : (php_var)false)
