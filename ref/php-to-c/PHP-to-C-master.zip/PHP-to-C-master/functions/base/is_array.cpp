#define is_array(var) ((var).type == PHP_ARRAY ? (php_var)true : (php_var)false)
