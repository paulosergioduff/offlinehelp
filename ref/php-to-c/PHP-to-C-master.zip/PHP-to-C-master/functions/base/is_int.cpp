#define is_int(var) ((var).type == PHP_INT ? (php_var)true : (php_var)false)
