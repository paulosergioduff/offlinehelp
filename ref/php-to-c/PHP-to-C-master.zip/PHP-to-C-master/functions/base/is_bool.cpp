#define is_bool(var) ((var).type == PHP_BOOL ? (php_var)true : (php_var)false)
