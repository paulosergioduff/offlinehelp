#define MYSQL_ASSOC 1
#define MYSQL_NUM 2
#define MYSQL_BOTH 3
php_var global_mysql;
