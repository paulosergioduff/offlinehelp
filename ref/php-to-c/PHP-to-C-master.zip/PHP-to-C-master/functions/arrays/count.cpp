#define count(var) ((php_var) (var).keys.size())
